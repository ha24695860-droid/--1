const resultBody = document.getElementById("resultBody");
const approvedCount = document.getElementById("approvedCount");
const rejectedCount = document.getElementById("rejectedCount");
const approvedAmount = document.getElementById("approvedAmount");
const rowCount = document.getElementById("rowCount");

const numberFormatter = new Intl.NumberFormat("ko-KR");

function formatNumber(value) {
  return numberFormatter.format(value);
}

function renderRows(items) {
  let approved = 0;
  let rejected = 0;
  let approvedTotal = 0;

  resultBody.innerHTML = "";

  items.forEach((item) => {
    const population = Number(item["인구수"]);
    const requested = Number(item["신청액"]);
    const limit = population * 10;
    const isApproved = requested <= limit;
    const status = isApproved ? "승인" : "반려";

    if (isApproved) {
      approved += 1;
      approvedTotal += requested;
    } else {
      rejected += 1;
    }

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${item["지자체명"]}</td>
      <td>${formatNumber(population)}</td>
      <td>${formatNumber(requested)}원</td>
      <td>${formatNumber(limit)}원</td>
      <td><span class="status ${isApproved ? "approved" : "rejected"}">${status}</span></td>
    `;
    resultBody.appendChild(tr);
  });

  approvedCount.textContent = approved;
  rejectedCount.textContent = rejected;
  approvedAmount.textContent = `${formatNumber(approvedTotal)}원`;
  rowCount.textContent = `${items.length}건`;
}

async function loadApplications() {
  try {
    const response = await fetch("신청목록.json", { cache: "no-store" });
    if (!response.ok) {
      throw new Error(`신청목록.json 로딩 실패: ${response.status}`);
    }

    const items = await response.json();

    if (!Array.isArray(items)) {
      throw new Error("JSON의 최상위 데이터는 배열이어야 합니다.");
    }

    renderRows(items);
  } catch (error) {
    resultBody.innerHTML = `
      <tr>
        <td colspan="5" class="error">
          데이터를 불러오지 못했습니다. Netlify/Vercel에
          신청목록.json 파일이 함께 배포되었는지 확인해 주세요.
        </td>
      </tr>
    `;
    console.error(error);
  }
}

loadApplications();
